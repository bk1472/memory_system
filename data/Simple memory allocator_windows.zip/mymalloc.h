#ifndef __MYMALLOC_H__
#define __MYMALLOC_H__

// Include/*{{{*/
#include <stdio.h>
#include <stdlib.h>/*}}}*/

#define MAXIMUM_TEST_COUNT 5000

// typedef/*{{{*/
typedef enum {FALSE, TRUE}BOOL;
struct _node{
	char* address;
	unsigned int size;

	struct _node* nn;
	struct _node* pn;

	BOOL isFree;
};
typedef struct _node node;/*}}}*/
// Function declare/*{{{*/
void* mymalloc(size_t size);
void myfree(void* addr);
node* dll_create();
node* search_free_node(size_t size);
node* search_node(void* addr);
BOOL check_sequence(node* n1, node* n2);/*}}}*/

#endif