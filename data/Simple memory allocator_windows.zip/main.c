///////////////////////////////////////////////////////////////////*{{{*/
// Title: Simple user-level memory allcator using double linked list
// Author: Jongmin Won
// Version: 1.0
// Recent update date: 27. 3. 2012.
//
// Description:
//  This program is simulating memory allocator including malloc and
//  free functions in user-level. The data structure used here is c-
//  irculaar double linked list. The purpose of this program is inc-
//  luding a assignment for Computer Enginnering Design class in Su-
//  ngkyunkwan University 2012 spring semester. This program has co-
//  pyleft, so you can freely use it.
/////////////////////////////////////////////////////////////////////*}}}*/

#include "mymalloc.h"
#include <Windows.h>

int main(void){
	char* mem_save[MAXIMUM_TEST_COUNT] = {0,};
	unsigned int count = 0;
	LARGE_INTEGER ticksPerSecond, start_ticks, end_ticks; // For elapsed time1

	QueryPerformanceCounter(&start_ticks); // For elapsed time2

	printf("[Program] Simple Memory Allocator\n");
	printf("[System] Start malloc process..\n");
	for(count = 0; count < MAXIMUM_TEST_COUNT; count++){
		mem_save[count] = (char*)mymalloc(sizeof(char) * 4 * 1024);
		if(mem_save[count] == 0){
			printf("[Error] Allocation error\n");
		}
	}	
	printf("[System] Allocation process end\n");
	printf("[System] Free process start\n");	
	for(count = 0; count < MAXIMUM_TEST_COUNT; count++){
		myfree(mem_save[count]);
	}
	printf("[System] Free process ends\n");

	QueryPerformanceCounter(&end_ticks); // For elapsed time3
	QueryPerformanceFrequency(&ticksPerSecond); // For elapsed time4
	printf("Elapsed CPU time:   %.12f  sec\n\n", (((double)end_ticks.QuadPart- start_ticks.QuadPart)/(double)ticksPerSecond.QuadPart)); // For elapsed time5

	printf("[System] Quit Program\n");
	return 0;
}
