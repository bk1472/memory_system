#ifndef __MYMALLOC_H__
#define __MYMALLOC_H__

#include <stdio.h>
#include <stdlib.h>

// Define - Const
#define smallest_mem_space 8 // 8B
#define largest_mem_space (32*1024*1024) // 32MB
#define highest_order  21 // 8B * 2^22 = 32MB;
#define MAXIMUM_TEST_COUNT 500

// typedef
typedef enum {FALSE, TRUE} BOOL;
struct _buddy{
	unsigned int address;
	unsigned int size;
	int order;

	struct _buddy* parent;
	struct _buddy* left;
	struct _buddy* right;

	BOOL occupied;
	BOOL spilt;
};
typedef struct _buddy buddy;
struct _queue_item{
	buddy* b;
	struct _queue_item* li;
	struct _queue_item* ui;
};
typedef struct _queue_item queue_item;

typedef struct{
	queue_item* head;
	queue_item* tail;
}queue;

// Function declare/*{{{*/
void* mymalloc(size_t size);
void myfree(void* addr);
void buddy_init(buddy* b);
void buddy_spilt(buddy* b);
void buddy_merge(buddy* b);
buddy* get_buddy(buddy* h, unsigned int order);
buddy* find_buddy(buddy* b);
buddy* search_buddy(unsigned int* addr); 
unsigned int check_order(size_t size);
void create_queue();
void destroy_queue();
BOOL isEmpty_queue();
buddy* dequeue();
void enqueue(buddy* b);/*}}}*/
#endif