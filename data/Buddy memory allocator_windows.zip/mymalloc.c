#include "mymalloc.h"

char* mybuffer; // It will has 32MB memory space from here.
buddy* buddy_head = 0;
queue* q;
unsigned int malloc_count = 0;
unsigned int free_count = 0;

void* mymalloc(size_t size) {/*{{{*/
	buddy* b;
	unsigned int order;

	if(buddy_head == 0){
		mybuffer = (char*)malloc(sizeof(char)* 32 * 1024 * 1024);
		buddy_head = (buddy*)malloc(sizeof(buddy));
		buddy_init(buddy_head);
	}

	order = check_order(size);
	b = get_buddy(buddy_head, order);

	if(b->order == order){
		b->occupied = TRUE;
		if(malloc_count++ == 1000){
			malloc_count = 0;
			printf("[Malloc] succeed 1: %u - %u (%u)\n", b->address, b->address + b->size, size);
		}
		return (void*)b->address;
	}
	else{
		for(buddy_spilt(b), b = b->left; b->order != order; buddy_spilt(b), b = b->left){
			if(b->order == 0){
				printf("[Malloc] Error: case1\n");
				exit(1);
			}
		}
		b->occupied = TRUE;
		if(malloc_count++ == 1000){
			malloc_count = 0;
			printf("[Malloc] succeed 2: %u - %u (%u)\n", b->address, b->address + b->size, size);
		}
		return (void*)b->address;
	}
	printf("[Mallc] Error: case2\n");
	exit(1);
}/*}}}*/
void myfree(void* addr){/*{{{*/
	buddy* b = search_buddy((unsigned int*)addr);
	buddy* b_buddy;

//	printf("[Myfree] required address: %u, searched address: %u\n",		(unsigned int)addr, b->address);
	if(b->order == highest_order){
		b->occupied = FALSE;
		return;
	}
	b_buddy = find_buddy(b);
	for(b_buddy = find_buddy(b); b_buddy->spilt == FALSE && b_buddy->occupied == FALSE; b_buddy = find_buddy(b)){
		b = b->parent;
		if(b->order == highest_order){
			b->occupied = FALSE;
			return;
		}
		buddy_merge(b);
	}
	b->occupied = FALSE;
}/*}}}*/
void buddy_init(buddy* b){/*{{{*/
	b->address = (unsigned int)mybuffer;
	b->size = largest_mem_space;
	b->order = highest_order;

	b->parent = 0;
	b->left = 0;
	b->right = 0;

	b->occupied = FALSE;
	b->spilt = FALSE;
}/*}}}*/
void buddy_spilt(buddy* b){/*{{{*/
	b->left = (buddy*)malloc(sizeof(buddy));
	b->right = (buddy*)malloc(sizeof(buddy));
	b->spilt = TRUE;

	b->left->address = b->address;
	b->left->size = b->size/2;
	b->left->order = b->order-1;
	b->left->parent = b;
	b->left->left = 0;
	b->left->right = 0;
	b->left->occupied = FALSE;
	b->left->spilt = FALSE;

	b->right->address = b->address + b->size/2;
	b->right->size = b->size/2;
	b->right->order = b->order-1;
	b->right->parent = b;
	b->right->left = 0;
	b->right->right = 0;
	b->right->occupied = FALSE;
	b->right->spilt = FALSE;
}/*}}}*/
void buddy_merge(buddy* b){/*{{{*/
	free(b->left);
	free(b->right);
	b->left = 0;
	b->right = 0;
	b->spilt = FALSE;
}/*}}}*/
buddy* get_buddy(buddy* h, unsigned int order){/*{{{*/
	buddy* b_temp;
	buddy* b = h;

	create_queue();
	enqueue(h);
	while(1){
		if(isEmpty_queue()){
			break; // No appropriate item
		}
		b_temp = dequeue();
		if((unsigned)b_temp->order < order)
			break;

		if(b_temp->occupied == TRUE){ // occupied
			continue;
		}
		else{ // non occupied
			if(b_temp->spilt == TRUE){ // spilt
				if(b_temp->left->occupied == FALSE)
					enqueue(b_temp->left);
				if(b_temp->right->occupied == FALSE)
					enqueue(b_temp->right);
			}
			else{ // non spilt
				if(b_temp->order == order){
					destroy_queue();
					return b_temp;
				}
				else if(((unsigned)b_temp->order > order) && (b->order > b_temp->order)){
					b = b_temp;
				}
			}
		}
	}
	destroy_queue();
	return b;
}/*}}}*/
buddy* find_buddy(buddy* b){/*{{{*/
	if(b->parent->left == b){
		return b->parent->right;
	}
	else if(b->parent->right == b){
		return b->parent->left;
	}
	else{
		printf("[Error] find_buddy error\n");
		exit(1);
	}
}/*}}}*/
buddy* search_buddy(unsigned int* addr){/*{{{*/
	unsigned int add = (unsigned int)addr - (unsigned int)mybuffer;
	unsigned int count = 0;
	unsigned int size = largest_mem_space/2;
	unsigned int use_space[highest_order-1] = {0,};
	buddy* b = buddy_head;

//	printf("add: %u, addr: %u, mybuffer: %u\n", add, addr, mybuffer);
	for(; count < highest_order-1; count++, size/=2){
		if(add >= size){
			use_space[count] = 1;
			add -= size;
		}
	}
	
	for(count = 0; count < highest_order-1; count++){
		if(use_space[count] == 0){
			if(b->left != 0){
				b = b->left;
			}
			else{
				return b;
			}
		}
		else if(use_space[count] == 1){
			b = b->right;
		}
		else{
			printf("[System] search_buddy error\n");
			exit(1);
		}
	}
	return b;
}/*}}}*/
unsigned int check_order(size_t size){/*{{{*/
	unsigned int ref_size = smallest_mem_space;
	unsigned int order = 0;

	for(; size > ref_size; ref_size*=2, order++){
		if(ref_size > largest_mem_space){
			// Error
		}
	}
	return order-1;
}/*}}}*/
void create_queue(){/*{{{*/
	queue_item * item_head = (queue_item*)malloc(sizeof(queue_item));
	q = (queue*)malloc(sizeof(queue));
	
	item_head->b = 0;
	item_head->li = 0;
	item_head->ui = 0;

	q->head = item_head;
	q->tail = item_head;
}/*}}}*/
void destroy_queue(){/*{{{*/
	queue_item* qi = q->tail;
	queue_item* temp;
	while(qi->li != 0){
		temp = qi;
		qi = qi->li;
		free(temp);
	}
	free(q->head);
	free(q);
}/*}}}*/
BOOL isEmpty_queue(){/*{{{*/
	if(q->tail->li == 0)
		return TRUE;
	else
		return FALSE;
}/*}}}*/
buddy* dequeue(){/*{{{*/
	buddy* b;
	queue_item* qi;
	if(!isEmpty_queue()){
		b = q->head->ui->b;
		qi = q->head->ui;
		q->head->ui = q->head->ui->ui;
		if(q->head->ui != 0){
			q->head->ui->li = q->head;
		}
		if(qi == q->tail){
			q->tail = q->head;
		}
		free(qi);
		return b;
	}
	else{
		return 0;
	}
}/*}}}*/
void enqueue(buddy* b){/*{{{*/
	q->tail->ui = (queue_item*)malloc(sizeof(queue_item));
	q->tail->ui->li = q->tail;
	q->tail = q->tail->ui;

	q->tail->b = b;
	q->tail->ui = 0;
}	