#include "do.h"

int main() {
	main_do();
	return 0;
}

