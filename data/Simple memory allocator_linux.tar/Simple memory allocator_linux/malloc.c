///////////////////////////////////////////////////////////////////*{{{*/
// Title: Simple user-level memory allcator using double linked list
// Author: Jongmin Won
// Version: 1.0
// Recent update date: 27. 3. 2012.
//
// Description:
//  This program is simulating memory allocator including malloc and
//  free functions in user-level. The data structure used here is c-
//  irculaar double linked list. The purpose of this program is inc-
//  luding a assignment for Computer Enginnering Design class in Su-
//  ngkyunkwan University 2012 spring semester. This program has co-
//  pyleft, so you can freely use it.
/////////////////////////////////////////////////////////////////////*}}}*/

// Include/*{{{*/
#include <stdio.h>
#include <stdlib.h>/*}}}*/
// typedef/*{{{*/
typedef enum {false, true}bool;
struct _node{
	char* address;
	unsigned int size;

	struct _node* nn;
	struct _node* pn;

	bool isFree;
};
typedef struct _node node;/*}}}*/
// Function declare/*{{{*/
void* mymalloc(size_t size);
void myfree(void* addr);
node* dll_create();
node* search_free_node(size_t size);
node* search_node(void* addr);
bool check_sequence(node* n1, node* n2);/*}}}*/

node* node_head = 0;
char* mybuffer;
unsigned int malloc_count = 0;
unsigned int free_count = 0;

void* mymalloc(size_t size){/*{{{*/
	node* n = 0;
	node* temp = 0;

	if(node_head == 0){ // For first use
		node_head = dll_create();	
	}
	temp = search_free_node(size); // Find appropriate free node
	if(temp != 0){ // If there is such kind of node
		n = (node*)malloc(sizeof(node));
		n->address = temp->address;
		n->size = size;
		n->nn = temp;
		n->pn = temp->pn;
		n->isFree = false;

		temp->address += size;
		temp->size -= size;
		temp->pn->nn = n;
		temp->pn = n;
	}
	else{ // Fail to find appropriate node
		printf("[Malloc] malloc is failed: no suitable node\n");
		return 0;
	}
	return n->address;
}/*}}}*/
void myfree(void* addr){/*{{{*/
	node* n = 0;
	node* temp = 0;

	if(!(n = search_node(addr))){ // There is no node which has the address
		printf("[Free] free is failed: no node which has the address\n");
		return;
	}
	if((n->pn->isFree == true) & (n->nn->isFree == true)){
		if((n->pn->isFree == true) && (check_sequence(n->pn, n) == true)){ // Previous node is free
			n->pn->size += n->size;
			n->pn->nn = n->nn;
			n->nn->pn = n->pn;
			if((n->nn->isFree == true) && (n->nn != n->pn && (check_sequence(n,n->nn) == true))){ // Both side of the node is free node
				n->pn->size += n->nn->size;
				n->pn->nn = n->nn->nn;
				n->nn->nn->pn = n->pn;
				free(n->nn);
			}	
			free(n);

		}
		else if(check_sequence(n, n->nn) == true){ // Only next node is free
			temp = n->nn;

			n->nn->address -= n->size;
			n->nn->size += n->size;
			n->pn->nn = n->nn;
			n->nn->pn = n->pn;

			free(temp);
		}
	}
	else{ // The node is between already used nodes
		n->isFree = true;
	}
}/*}}}*/
node* dll_create(){/*{{{*/
	mybuffer = (char*)malloc(sizeof(char) * 50 * 1024 * 1024);
	node* n = (node*)malloc(sizeof(node));

//	n->address = (char*)start_address; // 0x27315
	n->address = mybuffer;
	n->size = 50 * 1024 * 1024; // 50MB
	n->nn = n;
	n->pn = n;
	n->isFree = true;

	return n;
}/*}}}*/
node* search_free_node(size_t size){/*{{{*/
	node* n = node_head;

	while(1){
		if(n->isFree == true && n->size > size){ // Suitable free node
			return n;
		}
		else{
			n = n->nn;
			if(n == node_head) // Fail to find appropriate free node
				return 0;
		}
	}
}/*}}}*/
node* search_node(void* addr){/*{{{*/
	node* n =  node_head;

	while(1){
		if(n->address == (char*)addr){
			return n;
		}
		else{
			n = n->nn;
			if(n == node_head) // There is no node which has the address 
				return 0;
		}
	}
}/*}}}*/
bool check_sequence(node* n1, node* n2){/*{{{*/
	if(n1->address + n1->size == n2->address)
		return true;
	else
		return false;
}/*}}}*/
